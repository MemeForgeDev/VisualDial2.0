// ============================================================
//  dashboard.js — Mozilla WebExtension
//  Uses: db.js (IndexedDB)  |  browser.* API
//  NO chrome.bookmarks — all data from IndexedDB
// ============================================================

let draggedItem = null;
let allCards = [];

const cardW = 230;
const cardH = 135;
const gap = 20;

document.addEventListener('DOMContentLoaded', async () => {

    const grid = document.getElementById('bookmarks-grid');
    const settingsBtn = document.getElementById('settings-btn');
    const settingsModal = document.getElementById('settings-modal');
    const folderModal = document.getElementById('folder-modal');
    const backgrounds = ['bg1.jpg', 'bg2.jpg', 'bg3.jpg', 'bg4.jpg', 'bg5.jpg'];

    // ===========================================================
    //  FIRST-RUN INIT — default background + default folder
    // ===========================================================
    async function firstRunInit() {
        const data = await browser.storage.local.get('firstRunComplete');
        if (data.firstRunComplete) return;

        await browser.storage.local.set({
            userBackground: 'bg1.jpg',
            isCustomBg: false
        });

        await ensureRoot();
        const rootChildren = await getAllDials('root');
        if (rootChildren.length === 0) {
            await saveDial({
                id:         genId(),
                folderId:   'root',
                folderName: 'Speed Dial',
                title:      'Other bookmarks',
                url:        '',
                image:      '',
                order:      0,
                isFolder:   true
            });
        }

        await browser.storage.local.set({ firstRunComplete: true });
    }

    await firstRunInit();

    // ===========================================================
    //  REFLOW — card positioning
    // ===========================================================
    function reflow() {
        if (!grid || allCards.length === 0) return;
        const containerWidth = grid.offsetWidth;
        const cols = Math.max(1, Math.floor(containerWidth / (cardW + gap)));
        const totalWidth = cols * cardW + (cols - 1) * gap;
        const startX = (containerWidth - totalWidth) / 2;

        allCards.forEach((wrapper, index) => {
            const row = Math.floor(index / cols);
            const col = index % cols;
            wrapper.style.transform = `translate(${startX + col * (cardW + gap)}px, ${row * (cardH + gap + 30)}px)`;
            wrapper.style.opacity = '1';
        });

        grid.style.height = `${Math.ceil(allCards.length / cols) * (cardH + gap)}px`;
    }

    // ===========================================================
    //  SEARCH
    // ===========================================================
    const searchInput = document.getElementById('search-input');
    const engineSelect = document.getElementById('search-engine-select');
    const searchBtn = document.getElementById('search-btn');
    const urlPattern = /^(https?:\/\/)?([\w\d-]+\.)+[\w-]+(\/.*)?$/i;

    browser.storage.local.get('searchEngine').then(data => {
        if (data.searchEngine) engineSelect.value = data.searchEngine;
    });

    engineSelect.onchange = () =>
        browser.storage.local.set({ searchEngine: engineSelect.value });

    function doSearch() {
        let q = searchInput.value.trim();
        if (!q) return;
        if (urlPattern.test(q)) {
            window.location.href = q.startsWith('http') ? q : 'https://' + q;
        } else {
            window.location.href = (engineSelect.value || 'https://www.google.com/search?q=') + encodeURIComponent(q);
        }
    }

    searchInput.onkeydown = (e) => { if (e.key === 'Enter') doSearch(); };
    searchBtn.onclick = doSearch;

    // ===========================================================
    //  BACKGROUND IMAGE
    // ===========================================================
    function renderSettingsUI() {
        const bgGrid = document.getElementById('bg-selection-grid');
        if (!bgGrid) return;
        bgGrid.innerHTML = '';

        browser.storage.local.get('userBackground').then(data => {
            backgrounds.forEach(bg => {
                const div = document.createElement('div');
                const bgPath = browser.runtime.getURL(`backgrounds/${bg}`);
                div.className = `bg-option ${data.userBackground === bg ? 'selected' : ''}`;
                div.style.cssText = `background-image:url('${bgPath}');background-size:cover;background-position:center`;
                div.onclick = () => {
                    document.body.style.backgroundImage = `url('${bgPath}')`;
                    browser.storage.local.set({ userBackground: bg, isCustomBg: false });
                    renderSettingsUI();
                };
                bgGrid.appendChild(div);
            });
        });
    }

    document.getElementById('choice-custom-bg').onclick = () => {
        settingsModal.style.display = 'none';
    };

    browser.storage.local.get(['userBackground', 'isCustomBg']).then(data => {
        if (data.userBackground) {
            const bgPath = data.isCustomBg
                ? data.userBackground
                : browser.runtime.getURL(`backgrounds/${data.userBackground}`);
            document.body.style.backgroundImage = `url('${bgPath}')`;
        }
    });

    // ===========================================================
    //  FOLDER PREVIEW (4 thumbnails from IndexedDB)
    // ===========================================================
    async function createFolderPreviewHTML(folderId) {
        const children = (await getAllDials(folderId)).filter(d => !d.isFolder);
        let html = '<div class="folder-grid-preview">';
        for (let i = 0; i < 4; i++) {
            const bm = children[i];
            const img = bm?.image || '';
            html += `<div class="mini-preview" style="${img ? `background-image:url('${img}')` : 'background:#ffffff1e;'}"></div>`;
        }
        return html + '</div>';
    }

    // ===========================================================
    //  CREATE CARD
    //  dragCtx = null  → no drag-and-drop
    //  dragCtx = { grid, cards, folderId }  → with drag-and-drop
    // ===========================================================
    async function createCard(item, dragCtx = null) {
        const wrapper = document.createElement('div');
        wrapper.className = 'card-wrapper';
        wrapper.dataset.id = item.id;

        if (dragCtx) {
            wrapper.draggable = true;
            wrapper.style.opacity = '0';
        }

        // Image
        let imageHTML = '';
        if (item.isFolder) {
            const preview = await createFolderPreviewHTML(item.id);
            imageHTML = `<div class="card-image folder-preview">${preview}</div>`;
        } else {
            imageHTML = `<div class="card-image" style="${item.image ? `background-image:url('${item.image}')` : ''}"></div>`;
        }

        wrapper.innerHTML = `
        <div class="card ${item.isFolder ? 'folder-card' : ''}">
            <div class="card-controls">
                <button class="icon-btn-mini edit-btn">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640">
                        <path d="M416.9 85.2L372 130.1L509.9 268L554.8 223.1C568.4 209.6 576 191.2 576 172C576 152.8 568.4 134.4 554.8 120.9L519.1 85.2C505.6 71.6 487.2 64 468 64C448.8 64 430.4 71.6 416.9 85.2zM338.1 164L122.9 379.1C112.2 389.8 104.4 403.2 100.3 417.8L64.9 545.6C62.6 553.9 64.9 562.9 71.1 569C77.3 575.1 86.2 577.5 94.5 575.2L222.3 539.7C236.9 535.6 250.2 527.9 261 517.1L476 301.9L338.1 164z"/>
                    </svg>
                </button>
                <button class="icon-btn-mini delete-btn">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512">
                        <path d="M55.1 73.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L147.2 256 9.9 393.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L192.5 301.3 329.9 438.6c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L237.8 256 375.1 118.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L192.5 210.7 55.1 73.4z"/>
                    </svg>
                </button>
            </div>
            ${imageHTML}
            <div class="card-info"><div class="card-title">${item.title}</div></div>
        </div>`;

        // ---- DRAG & DROP ----
        if (dragCtx) {
            const { cards, folderId } = dragCtx;
            const ctxGrid = dragCtx.grid;

            wrapper.ondragstart = (e) => {
                draggedItem = wrapper;
                wrapper.classList.add('dragging');
                e.dataTransfer.effectAllowed = 'move';
            };
            wrapper.ondragend = () => {
                wrapper.classList.remove('dragging');
                cards.forEach(c => c.classList.remove('drag-over'));
                draggedItem = null;
            };
            wrapper.ondragover = (e) => {
                e.preventDefault();
                if (draggedItem && draggedItem !== wrapper)
                    wrapper.classList.add('drag-over');
            };
            wrapper.ondragleave = () => wrapper.classList.remove('drag-over');

            wrapper.ondrop = async (e) => {
                e.preventDefault();
                wrapper.classList.remove('drag-over');
                const target = e.target.closest('.card-wrapper');
                if (!draggedItem || !target || draggedItem === target) { draggedItem = null; return; }

                const dragged = draggedItem;
                const fromIdx = cards.indexOf(dragged);
                const toIdx   = cards.indexOf(target);

                if (fromIdx !== -1 && toIdx !== -1) {
                    cards.splice(fromIdx, 1);
                    cards.splice(toIdx, 0, dragged);

                    if (fromIdx < toIdx) ctxGrid.insertBefore(dragged, target.nextSibling);
                    else                 ctxGrid.insertBefore(dragged, target);

                    // Modal cards aren't positioned with transform, so reflow
                    // is only called for the main view (where grid === global grid)
                    if (ctxGrid === grid) reflow();

                    await updateDialOrder(cards.map(c => c.dataset.id), folderId);
                }
                draggedItem = null;
            };
        }

        // ---- EDIT BUTTON ----
        wrapper.querySelector('.edit-btn').onclick = async (e) => {
            e.stopPropagation();

            if (!item.isFolder) {
                // Bookmark editing
                const bmModal = document.getElementById('bookmark-edit-modal');
                const bmName = document.getElementById('bm-edit-name');
                const bmUrl = document.getElementById('bm-edit-url');
                const bmImg = document.getElementById('bm-edit-image');
                const bmPreview = document.getElementById('bm-edit-preview');
                const bmSaveBtn = document.getElementById('save-bm-edit-btn');

                bmName.value = item.title;
                bmUrl.value = item.url;
                bmImg.value = item.image || '';
                bmPreview.style.backgroundImage = item.image ? `url('${item.image}')` : '';

                bmImg.oninput = () => {
                    bmPreview.style.backgroundImage = `url('${bmImg.value.trim()}')`;
                };

                document.getElementById('btn-use-favicon').onclick = (ev) => {
                    ev.preventDefault();
                    try {
                        const domain = new URL(bmUrl.value || item.url).hostname;
                        const icon = `https://www.google.com/s2/favicons?sz=128&domain=${domain}`;
                        bmImg.value = icon;
                        bmPreview.style.backgroundImage = `url('${icon}')`;
                    } catch { console.error('URL error'); }
                };

                bmModal.style.display = 'flex';
                setTimeout(() => { bmName.focus(); bmName.select(); }, 50);

                bmSaveBtn.onclick = async () => {
                    const updated = {
                        ...item,
                        title: bmName.value.trim() || item.title,
                        url: bmUrl.value.trim() || item.url,
                        image: bmImg.value.trim()
                    };
                    await saveDial(updated);
                    Object.assign(item, updated);

                    wrapper.querySelector('.card-title').textContent = updated.title;
                    const cardImg = wrapper.querySelector('.card-image');
                    if (cardImg) cardImg.style.backgroundImage = updated.image ? `url('${updated.image}')` : '';
                    bmModal.style.display = 'none';
                };

                document.getElementById('close-bookmark-edit').onclick = () =>
                    bmModal.style.display = 'none';

            } else {
                // Folder editing
                const editModal = document.getElementById('edit-modal');
                const nameInput = document.getElementById('edit-name-input');
                const saveBtn = document.getElementById('save-edit-btn');

                nameInput.value = item.title;
                editModal.style.display = 'flex';

                saveBtn.onclick = async () => {
                    const newTitle = nameInput.value.trim();
                    if (newTitle) {
                        await renameFolder(item.id, newTitle);
                        item.title = newTitle;
                        wrapper.querySelector('.card-title').textContent = newTitle;
                    }
                    editModal.style.display = 'none';
                };

                document.getElementById('close-edit').onclick = () =>
                    editModal.style.display = 'none';
            }
        };

        // ---- DELETE BUTTON ----
        wrapper.querySelector('.delete-btn').onclick = async (e) => {
            e.stopPropagation();
            if (!confirm('Delete?')) return;

            if (item.isFolder) await deleteFolderDeep(item.id);
            else await deleteDial(item.id);

            wrapper.remove();
            if (dragCtx && dragCtx.grid === grid) {
                allCards = allCards.filter(c => c !== wrapper);
                reflow();
            }
        };

        // ---- CLICK ----
        wrapper.onclick = () => {
            if (item.isFolder) openFolderModal(item.id, item.title);
            else window.location.href = item.url;
        };

        return wrapper;
    }

    // ===========================================================
    //  FOLDER MODAL
    // ===========================================================
    async function openFolderModal(folderId, title) {
        const modalGrid = document.getElementById('modal-grid');
        const titleInput = document.getElementById('folder-title-input');

        modalGrid.innerHTML = '';
        folderModal.style.display = 'block';
        titleInput.value = title;

        titleInput.onchange = async () => {
            const newName = titleInput.value.trim();
            if (newName && newName !== title) {
                await renameFolder(folderId, newName);
                title = newName;
                initDashboard();
            }
        };

        const modalCards = [];
        const modalCtx   = { grid: modalGrid, cards: modalCards, folderId };

        const children = await getAllDials(folderId);
        for (const item of children) {
            const card = await createCard(item, modalCtx);
            card.style.opacity = '1'; // no transform animation in modal
            modalGrid.appendChild(card);
            modalCards.push(card);
        }
    }

    // ===========================================================
    //  MAIN INITIALIZATION — IndexedDB only
    // ===========================================================
    async function initDashboard() {
        await ensureRoot();

        const items = await getAllDials('root');

        grid.innerHTML = '';
        allCards = [];

        const mainCtx = { grid, cards: allCards, folderId: 'root' };

        for (const item of items) {
            const card = await createCard(item, mainCtx);
            grid.appendChild(card);
            allCards.push(card);
        }

        setTimeout(reflow, 100);
    }

    // ===========================================================
    //  EVENTS
    // ===========================================================
    settingsBtn.onclick = () => {
        renderSettingsUI();
        settingsModal.style.display = 'flex';
    };

    document.getElementById('close-settings').onclick = () =>
        settingsModal.style.display = 'none';

    document.getElementById('close-modal').onclick = () =>
        folderModal.style.display = 'none';

    window.addEventListener('resize', reflow);

    // ===========================================================
    //  START
    // ===========================================================
    await initDashboard();
});