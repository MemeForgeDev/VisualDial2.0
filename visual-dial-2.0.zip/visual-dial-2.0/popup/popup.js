// ============================================================
//  popup.js — Mozilla WebExtension
//  Uses: db.js  |  browser.* API
//  NO chrome.bookmarks — everything goes to IndexedDB
//  Canvas: 230x135px
// ============================================================

const CANVAS_W = 230;
const CANVAS_H = 135;

document.addEventListener('DOMContentLoaded', async () => {

    const titleInput   = document.getElementById('title-input');
    const folderSelect = document.getElementById('folder-select');
    const webpageImg   = document.getElementById('webpage-img-element');
    const canvas       = document.getElementById('safe-canvas');
    const ctx          = canvas.getContext('2d');

    canvas.width  = CANVAS_W;
    canvas.height = CANVAS_H;

    const colors = ['#0b70b4','#790e3b','#0f7272','#7e860a','#eb950a','#e21934','#00798c','#302b81','#308f6b','#277da1'];
    const bgColor = colors[Math.floor(Math.random() * colors.length)];

    // Active tab
    const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
    titleInput.value = tab.title;

    // ---- CANVAS ----
    function drawSafeImage(text) {
        const match     = text.match(/\p{L}/u);
        const firstWord = text.substring(match ? match.index : 0).split(' ')[0] || 'Dial';

        ctx.fillStyle    = bgColor;
        ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);
        ctx.shadowColor  = 'rgba(0,0,0,0.25)';
        ctx.shadowBlur   = 5;
        ctx.fillStyle    = 'white';
        ctx.font         = "bold 28px 'Segoe UI', Arial";
        ctx.textAlign    = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(firstWord, CANVAS_W / 2, CANVAS_H / 2);
        ctx.shadowBlur   = 0;
    }

    // ---- SCREENSHOT → 230x135 (cover-fit) ----
    function resizeToCard(srcDataUrl) {
        return new Promise((resolve) => {
            const img = new Image();
            img.onload = () => {
                const off = document.createElement('canvas');
                off.width  = CANVAS_W;
                off.height = CANVAS_H;
                const oc   = off.getContext('2d');
                const scale   = Math.max(CANVAS_W / img.width, CANVAS_H / img.height);
                const drawW   = img.width  * scale;
                const drawH   = img.height * scale;
                oc.drawImage(img, (CANVAS_W - drawW) / 2, (CANVAS_H - drawH) / 2, drawW, drawH);
                resolve(off.toDataURL('image/png'));
            };
            img.src = srcDataUrl;
        });
    }

    // ---- SCREENSHOT ----
    async function initScreenshot() {
        if (tab.url.startsWith('about:') || tab.url.startsWith('moz-extension:')) {
            document.querySelector('input[value="safe"]').checked = true;
            return;
        }
        setTimeout(async () => {
            try {
                const shot = await browser.tabs.captureVisibleTab(null, { format: 'jpeg', quality: 30 });
                if (shot) {
                    webpageImg.src = shot;
                    document.querySelector('input[value="webpage"]').checked = true;
                }
            } catch {
                document.querySelector('input[value="safe"]').checked = true;
            }
        }, 250);
    }

    // ---- LOAD FOLDERS FROM IndexedDB ----
    async function loadFolders() {
        folderSelect.innerHTML = '';
        await ensureRoot();

        // Root option — always at top
        const rootOpt       = document.createElement('option');
        rootOpt.value       = 'root';
        rootOpt.textContent = '⭐ Speed Dial';
        folderSelect.appendChild(rootOpt);

        // Recursively add only subfolders (root not included)
        let folderCount = 0;
        async function populate(folderId, level) {
            const items = await getAllDials(folderId);
            for (const item of items) {
                if (!item.isFolder) continue;
                const opt       = document.createElement('option');
                opt.value       = item.id;
                opt.textContent = '\u00A0'.repeat(level * 3) + '└ ' + item.title;
                folderSelect.appendChild(opt);
                folderCount++;
                await populate(item.id, level + 1);
            }
        }
        await populate('root', 0);

        // If no folders exist — auto-create 'Other bookmarks'
        if (folderCount === 0) {
            const siblings   = await getAllDials('root');
            const autoFolder = {
                id:         genId(),
                folderId:   'root',
                folderName: 'Speed Dial',
                title:      'Other bookmarks',
                url:        '',
                image:      '',
                order:      siblings.length,
                isFolder:   true
            };
            await saveDial(autoFolder);

            const opt       = document.createElement('option');
            opt.value       = autoFolder.id;
            opt.textContent = '└ Other bookmarks';
            folderSelect.appendChild(opt);
            folderSelect.value = autoFolder.id;
        }
    }

    // ---- INIT ----
    drawSafeImage(tab.title);
    initScreenshot();
    await loadFolders();

    // ---- EVENTS ----
    titleInput.addEventListener('input', (e) => drawSafeImage(e.target.value));

    // New folder
    document.getElementById('new-folder-btn').onclick = async () => {
        const name = prompt('New folder name:');
        if (!name) return;

        const parentId  = folderSelect.value || 'root';
        const siblings  = await getAllDials(parentId);
        const parentRec = await getDial(parentId);

        const newFolder = {
            id:         genId(),
            folderId:   parentId,
            folderName: parentRec?.title || 'Speed Dial',
            title:      name,
            url:        '',
            image:      '',
            order:      siblings.length,
            isFolder:   true
        };
        await saveDial(newFolder);
        await loadFolders();
        folderSelect.value = newFolder.id;
    };

    // Save
    document.getElementById('done-btn').onclick = async () => {
        const choice   = document.querySelector('input[name="preview-choice"]:checked').value;
        let   imgData  = '';

        if (choice === 'webpage' && webpageImg.src && webpageImg.complete) {
            imgData = await resizeToCard(webpageImg.src);
        } else {
            imgData = canvas.toDataURL('image/png');
        }

        const folderId  = folderSelect.value || 'root';
        if (!folderId) return;
        const siblings  = await getAllDials(folderId);
        const folderRec = await getDial(folderId);

        const newDial = {
            id:         genId(),
            folderId:   folderId,
            folderName: folderRec?.title || 'Speed Dial',
            title:      titleInput.value.trim() || tab.title,
            url:        tab.url,
            image:      imgData,
            order:      siblings.length,
            isFolder:   false
        };

        await saveDial(newDial);
        window.close();
    };

    document.getElementById('cancel-btn').onclick = () => window.close();
});