// ============================================================
//  db.js — Speed Dial complete database (IndexedDB)
//  NO chrome.bookmarks. Everything is stored here.
//
//  Record structure:
//  {
//    id        : string  — unique id (genId())
//    folderId  : string  — parent folder id or 'root'
//    folderName: string  — parent folder name (cached for convenience)
//    title     : string  — title
//    url       : string  — URL (empty '' for folders)
//    image     : string  — base64 PNG 230x135 or ''
//    order     : number  — sort index
//    isFolder  : boolean
//  }
// ============================================================

const DB_NAME    = 'SpeedDialDB';
const DB_VERSION = 1;
const STORE      = 'dials';

// ----- Open DB -----
function openDB() {
    return new Promise((resolve, reject) => {
        const req = indexedDB.open(DB_NAME, DB_VERSION);

        req.onupgradeneeded = (e) => {
            const db = e.target.result;
            if (!db.objectStoreNames.contains(STORE)) {
                const store = db.createObjectStore(STORE, { keyPath: 'id' });
                store.createIndex('folderId', 'folderId', { unique: false });
                store.createIndex('order',    'order',    { unique: false });
            }
        };

        req.onsuccess = (e) => resolve(e.target.result);
        req.onerror   = (e) => reject(e.target.error);
    });
}

// ----- Get all records in a specific folder (sorted by order) -----
async function getAllDials(folderId = 'root') {
    const db = await openDB();
    return new Promise((resolve, reject) => {
        const tx    = db.transaction(STORE, 'readonly');
        const index = tx.objectStore(STORE).index('folderId');
        const req   = index.getAll(folderId);
        req.onsuccess = () =>
            resolve(req.result.sort((a, b) => (a.order ?? 0) - (b.order ?? 0)));
        req.onerror = (e) => reject(e.target.error);
    });
}

// ----- Get a single record by id -----
async function getDial(id) {
    const db = await openDB();
    return new Promise((resolve, reject) => {
        const req = db.transaction(STORE, 'readonly').objectStore(STORE).get(id);
        req.onsuccess = () => resolve(req.result ?? null);
        req.onerror   = (e) => reject(e.target.error);
    });
}

// ----- Save / update a record -----
async function saveDial(record) {
    const db = await openDB();
    return new Promise((resolve, reject) => {
        const tx  = db.transaction(STORE, 'readwrite');
        const req = tx.objectStore(STORE).put(record);
        req.onsuccess = () => resolve(req.result);
        req.onerror   = (e) => reject(e.target.error);
    });
}

// ----- Delete a record -----
async function deleteDial(id) {
    const db = await openDB();
    return new Promise((resolve, reject) => {
        const tx  = db.transaction(STORE, 'readwrite');
        const req = tx.objectStore(STORE).delete(id);
        req.onsuccess = () => resolve();
        req.onerror   = (e) => reject(e.target.error);
    });
}

// ----- Save the new order -----
async function updateDialOrder(orderedIds, folderId = 'root') {
    const db    = await openDB();
    const tx    = db.transaction(STORE, 'readwrite');
    const store = tx.objectStore(STORE);

    return new Promise((resolve, reject) => {
        let i = 0;
        function next() {
            if (i >= orderedIds.length) { resolve(); return; }
            const id     = orderedIds[i++];
            const getReq = store.get(id);
            getReq.onsuccess = () => {
                const rec = getReq.result;
                if (rec && rec.folderId === folderId) {
                    rec.order = i - 1;
                    store.put(rec);
                }
                next();
            };
            getReq.onerror = (e) => reject(e.target.error);
        }
        next();
        tx.onerror = (e) => reject(e.target.error);
    });
}

// ----- Delete a folder recursively with all its children -----
async function deleteFolderDeep(folderId) {
    const children = await getAllDials(folderId);
    for (const child of children) {
        if (child.isFolder) await deleteFolderDeep(child.id);
        else                 await deleteDial(child.id);
    }
    await deleteDial(folderId);
}

// ----- Rename a folder (updates folderName in all children) -----
async function renameFolder(folderId, newName) {
    const folder = await getDial(folderId);
    if (!folder) return;
    await saveDial({ ...folder, title: newName });

    // Update folderName cache for all direct children
    const children = await getAllDials(folderId);
    for (const child of children) {
        await saveDial({ ...child, folderName: newName });
    }
}

// ----- Generate a unique id -----
function genId() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

// ----- Ensure that the 'root' folder exists -----
async function ensureRoot() {
    const root = await getDial('root');
    if (!root) {
        await saveDial({
            id:         'root',
            folderId:   null,
            folderName: '',
            title:      'Speed Dial',
            url:        '',
            image:      '',
            order:      0,
            isFolder:   true
        });
    }
}
